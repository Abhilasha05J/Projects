const createSlice = require('@reduxjs/toolkit').createSlice //used require because it's a node js environemnt not a react application cna't use ES module import

const initialState = {
    numOfCakes:10
}


const cakeSlice = createSlice({   // create slice will automatically generates a function as same name we created the reducer
    name:'cake',//name of slice
    initialState, // if key and value both are same
    reducers:{
        ordered:state=> {  //order as a key and a arrow function with a state as parameter
            state.numOfCakes--  //we dont have to explicitly return the new state , we can directly mutate the state
        },
        restocked:(state, action)=>{
            state.numOfCakes += action.payload
        },
    },

})

module.exports = cakeSlice.reducer//default export
module.exports.cakeActions = cakeSlice.actions//named



