
console.log('From Index.js')
const redux = require('redux')
const CreateStore = redux.createStore
const bindActionCreators = redux.bindActionCreators // import the helper function
const combineReducers = redux.combineReducers // method to combine the reducers

const applyMiddleware = redux.applyMiddleware
const reduxLogger = require('redux-logger')
const logger = reduxLogger.createLogger()//logger middleware

const CAKE_ORDERED = "CAKE_ORDERED";
const CAKE_RESTOCKED = "CAKE_RESTOCKED";
const  ICECREAME_ORDERED = "ICECREAME_ORDERED";
const  ICECREAME_RESTOCKED = "ICECREAME_RESTOCKED";


// const initialState = //state
// {
// numOfCakes:10,
// numOfIceCreams:20,
// }

const initialCakeState = {
    numOfCakes:10,
}

const initialIceCreamState = {
    numOfIceCreams:20,
}
function orderCake() //actioncreator
{
  return {  //action
    type: CAKE_ORDERED,
   
  }

}

function restockCake(qty = 1) 
{
    return{
        type: CAKE_RESTOCKED,
        quantity:qty,
    }
}


function orderIceCream(qty=1)
{
    return{
        type: ICECREAME_ORDERED,
        payload:qty
    }
}

function restockIceCream(qty=1)
{
    return{
        type: ICECREAME_RESTOCKED,
        payload:qty,
    }
}
const cakereducer = (state = initialCakeState,action) =>  //reducer
{
switch(action.type)
{
  case CAKE_ORDERED:
    return {
     ...state, //copy of state and then make changes
      numOfCakes: state.numOfCakes - 1
    }
    case CAKE_RESTOCKED:
        return {
            ...state,
            numOfCakes : state.numOfCakes + action.quantity //add quantity to the current state of cakes
        }
  default:
    return state
}
}

const IceCreamreducer = (state = initialIceCreamState,action) =>  //reducer
{
switch(action.type)
{
    case ICECREAME_ORDERED:
        return{
            ...state,
            numOfIceCreams:state.numOfIceCreams-1,
        }
    case ICECREAME_RESTOCKED:
    return{
       ...state,
        numOfIceCreams: state.numOfIceCreams + action.payload,
    }
  default:
    return state
}
}

//combine both the reducer
const rootReducer = combineReducers({
    cake : cakereducer,  //creating key for each reducers
    iceCream: IceCreamreducer,
})
const store = CreateStore(rootReducer, applyMiddleware(logger)) //store created (you can pass as many middlewares as your application requires)
console.log('Initial state', store.getState())

const unsubscribe = store.subscribe(()=>{})//listner everytime the store update logs console on the store(subscribe to store)
// store.dispatch(orderCake())
// store.dispatch(orderCake())
// store.dispatch(orderCake())
// store.dispatch(restockCake(3)) //restock 3 cakes

const Actions = bindActionCreators({orderCake, restockCake,orderIceCream,restockIceCream},store.dispatch) 
Actions.orderCake()
Actions.orderCake()
Actions.orderCake()
Actions.restockCake(3)
Actions.orderIceCream()
Actions.orderIceCream()
Actions.orderIceCream()
Actions.restockIceCream(3)
unsubscribe()
//if you use dispatch after unsubscribing you want see the updated value on console (unsubscribe with changes)










