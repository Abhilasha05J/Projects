﻿namespace BusinessLogicLayer
{
    public class Class1
    {

    }
}
