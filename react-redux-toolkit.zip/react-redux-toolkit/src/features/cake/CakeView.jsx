import React from 'react'
import { useSelector,useDispatch} from 'react-redux'
import {ordered, restocked} from './cakeSlice'

export const CakeView = () => {
  const [value,setValue] = React.useState(1)
const numOfCakes = useSelector(state => state.cake.numOfCakes)
const dispatch = useDispatch()
  return (
    <div><table>
      <tbody>
        <tr>
      <td><h2>Number of Cakes - {numOfCakes}</h2></td>
      <td><button onClick={()=>dispatch(ordered())}>Order cake</button></td>
      <td>
      <input type = 'number' min="1" value={value} placeholder="Enter Quantity" onChange={(e=>setValue(parseInt(e.target.value)))} required/>
      <button onClick={()=>dispatch(restocked(value))}>Restock cakes</button></td>
      </tr>
      </tbody>
    </table>
        
        
  </div>
  )
}
