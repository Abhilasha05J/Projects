import {createSlice} from '@reduxjs/toolkit'

const initialState = {
    numOfCakes:10
}


const cakeSlice = createSlice({   
    name:'cake',
    initialState,
    reducers:{
        ordered:state=> {  
            if (state.numOfCakes > 0) {
                state.numOfCakes--;
            } else {
                alert('No cakes left to order');
            }
        },
        restocked:(state, action)=>{
            state.numOfCakes += action.payload
        }
    }

})

export default cakeSlice.reducer
export const {ordered, restocked} = cakeSlice.actions



