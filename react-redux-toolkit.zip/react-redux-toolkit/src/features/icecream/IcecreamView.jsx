import React from 'react'
import {useSelector,useDispatch } from 'react-redux'
import{ordered, restocked} from './icecreamSlice'

export const IcecreamView = () => {
  const [value,setValue] = React.useState(1)
  const numOfIcecreams = useSelector(state =>state.icecream.numOfIcecreams)
  const dispatch = useDispatch()
  return (
    <div>
      <table>
        <tbody>
          <tr>
        <td><h2>Number of Icecream -{numOfIcecreams}</h2></td>
        <td><button onClick={()=>{dispatch(ordered())}}>Order Icecream</button></td>
        <td>   
        <input type = 'number' min="1" value={value} placeholder="Enter Quantity" onChange={(e=>setValue(parseInt(e.target.value)))}/>
         <button onClick={()=>{dispatch(restocked(value))}}>Restock IceCream</button> </td>
         </tr>
         </tbody>
      </table>
        
     
    </div>
  )
}
